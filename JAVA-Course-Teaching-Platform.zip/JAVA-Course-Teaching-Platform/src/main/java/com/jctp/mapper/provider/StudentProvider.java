package com.jctp.mapper.provider;

public class StudentProvider {

}
